# -*- coding: utf-8 -*-
import linecache
import pickle

# 《中华人民共和国民事诉讼法》第一百四十四条
# removed = ['《中华人民共和国民事诉讼法》第一百四十四条', '关于适用《中华人民共和国婚姻法》若干问题的解释（一）第十六条', '关于适用《中华人民共和国婚姻法》若干问题的解释（一）第二条', '关于适用《中华人民共和国婚姻法》若干问题的解释（一）第五条', '关于适用《中华人民共和国婚姻法》若干问题的解释（一）第七条', '关于适用《中华人民共和国婚姻法》若干问题的解释（一）第十条', '关于适用《中华人民共和国婚姻法》若干问题的解释（一）第十三条']
# 主要改动这个函数就行
def generateSortedPredictDic(predictDic):
    sortedPredictDic = dict()
    for searchId in predictDic.keys():
        sortedRef = sorted(predictDic[searchId].items(), key=lambda x: x[1].get('prediction', 0), reverse=True)
        # sortedRef = sorted(predictDic[searchId].items(), key=lambda x: x[1]['sim'], reverse=True)
        # sortedRef = sorted(predictDic[searchId].items(), key=lambda x: 1 if x[1]['refed'] == 'yes' else 0, reverse=True)
        # sortedRef = sorted(predictDic[searchId].items(), key=lambda x: x[1]['rank'], reverse=False)
        # sortedRef = sorted(predictDic[searchId].items(), key=lambda x: x[1], reverse=True)
        temp = [item[0] for item in sortedRef]
        # for remove in removed:
        #     if remove in temp:
        #         temp.remove(remove)
        # temp = ['《中华人民共和国民事诉讼法》第一百四十四条', '《中华人民共和国婚姻法》第三十七条', '《中华人民共和国婚姻法》', '《中华人民共和国民事诉讼法》第六十四条', '《中华人民共和国婚姻法》第三十九条']
        sortedPredictDic[searchId] = temp
    return sortedPredictDic


def calculatePPF(topK, sortedPredictDic, testRefDic):
    topKPrecision = dict()
    topKRecall = dict()
    topKFvalue = dict()

    for topk in range(1, topK+1):
        topKPrecision[str(topk)] = 0
        topKRecall[str(topk)] = 0
        topKFvalue[str(topk)] = 0

    for searchId in sortedPredictDic:
        for topk in range(1, topK+1):
            tmpSortedPredicted = sortedPredictDic[searchId]
            if len(sortedPredictDic[searchId]) > topk:
                tmpSortedPredicted = sortedPredictDic[searchId][:topk]
            tmpCoverNum = len(set(tmpSortedPredicted) & set(testRefDic[searchId]))
            tmpRecall = 0
            if len(testRefDic[searchId]) != 0:
                tmpRecall = tmpCoverNum / len(testRefDic[searchId]) * 100
            tmpPrecision = tmpCoverNum / topk * 100
            tmpFvalue = 0
            if tmpRecall != 0 and tmpPrecision != 0:
                tmpFvalue = 2 * tmpRecall * tmpPrecision / (tmpPrecision + tmpRecall)

            topKPrecision[str(topk)] = tmpPrecision + topKPrecision[str(topk)]
            topKRecall[str(topk)] = topKRecall[str(topk)] + tmpRecall
            topKFvalue[str(topk)] = topKFvalue[str(topk)] + tmpFvalue
    precisionStr = 'precision:\t'
    recallStr = 'recall:\t'
    fvalueStr = 'fvalue:\t'
    topKStr = 'k:\t'
    for topk in range(1, topK+1):
        precisionStr = precisionStr + str(topKPrecision[str(topk)] / len(sortedPredictDic)) + '\t'
        recallStr = recallStr + str(topKRecall[str(topk)] / len(sortedPredictDic)) + '\t'
        fvalueStr = fvalueStr + str(topKFvalue[str(topk)] / len(sortedPredictDic)) + '\t'
        topKStr = topKStr + str(topk) + '\t'
    return precisionStr, recallStr, fvalueStr, topKStr


def loadDic(path):
    file = open(path, 'rb')
    dic = pickle.load(file)
    file.close()

    return dic


def prediction2result(prediction, test_data_file):
    result = {}

    qid = 0
    query_items = []
    for i in range(0, len(prediction)):
        # print('line:' + str(i))
        line = linecache.getline(test_data_file, i+1)
        space_index = line.find(' ')
        label = float(line[:space_index])

        sharp_index = line.find('#')
        searchId_lawname = line[sharp_index+1:]
        space_index = searchId_lawname.find(' ')
        searchId = searchId_lawname[:space_index]
        lawname = searchId_lawname[space_index+1:]
        lawname = lawname.strip()

        qid_index = line.find('qid:')
        line = line[qid_index + 4:]
        space_index = line.find(' ')
        line = line[:space_index]
        id = searchId

        p = float(prediction[i])
        # p = float(prediction[i].split(' ')[1])
        if id == qid:
            query_items.append([searchId, lawname, label, p])
        else:
            if len(query_items) != 0:
                query_items.sort(key=lambda elem: elem[-1], reverse=True)
                case = {}
                for i in range(0, len(query_items)):
                    item = query_items[i]
                    case[item[1]] = {'rank': i+1, 'prediction': item[3]}
                    if item[2] == 1:
                        case[item[1]]['refed'] = 1
                    else:
                        case[item[1]]['refed'] = 0
                result[query_items[0][0]] = case
            qid = id
            query_items = [[searchId, lawname, label, p]]
    query_items.sort(key=lambda elem: elem[-1], reverse=False)
    case = {}
    rank = 1
    for item in query_items:
        case[item[1]] = {'rank': rank}
        rank += 1
        if item[2] == 5:
            case[item[1]]['refed'] = 1
        else:
            case[item[1]]['refed'] = 0
    result[query_items[0][0]] = case
    return result


if __name__ == '__main__':
    # testRefDic = loadDic('source-data/search/all-ref-dic-search')
    testRefDic = loadDic('all-ref-dic-removesome-new')
    topK = 50

    # predictDic = loadDic('result_sim')
    # modeName = 'searchWeightTfidf'
    # predictDic = loadDic('source-data/search/' + modeName)
    # sortedPredictDic = generateSortedPredictDic(predictDic)
    # precisionStr, recallStr, fvalueStr, topKStr = calculatePPF(topK, sortedPredictDic, testRefDic)
    # print(modeName)
    # print(precisionStr)
    # print(recallStr)
    # print(fvalueStr)
    for i in range(4, 5):
        # file = open('cross_validate_data/svm-result/sim-num-bert/prediction-' + str(i), 'r')
        file = open('full-dlcm/prediction-' + str(i), 'r')
        prediction = file.readlines()
        file.close()
        # test_path = 'cross_validate_data/svm-rank-data/sim-num-bert/test-id-' + str(i) + '.dat'
        test_path = 'full-dlcm/test-' + str(i) + '.dat'
        predictDic = prediction2result(prediction, test_path)
        # 这里可以到generateSortedPredictDic中改动计算每一个推荐法条的具体得分的方法
        # 我这里是根据测试数据末尾记录的每一个法条名称和预测结果文件进行拼接的，也对推荐结果进行了排序
        sortedPredictDic = generateSortedPredictDic(predictDic)

        # 下面这个是输入排序结果和真实引用的文件就行了，不需要改动。
        precisionStr, recallStr, fvalueStr, topKStr = calculatePPF(topK, sortedPredictDic, testRefDic)
        print(precisionStr)
        print(recallStr)
        print(fvalueStr)
