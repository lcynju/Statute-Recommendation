import pymongo

con = pymongo.MongoClient('192.168.68.11', 20000)

class indexTable:
    def __init__(self):
        self.col = con.divorceCase3.indexTable

    def getCaselistByKeyfortfidf(self, word):
        res = dict()
        for item in self.col.find({"key" : word}):
            for case in item["caselist"]:
                res[case["caseid"]] = case["tfidf"]
        return res
if __name__ == '__main__':
    pass