import pymongo

def genSortStatutes(refList):
    refDic = {}

    for ref in refList:
        if ref in refDic:
            refDic[ref] += 1
        else:
            refDic[ref] = 1

    refList = [(k, v) for k, v in refDic.items()]

    res = sorted(refList, key=lambda x: x[1], reverse=True)
    res = [{'statute': x[0], 'count':x[1]} for x in res]

    return res

if __name__ == '__main__':
    con = pymongo.MongoClient('192.168.68.11', 20000)
    from_col = [
        con.divorceCase3.searchResWeightTfidf1,
        con.divorceCase3.searchResTwoWeightTfidf_IG1,
        con.divorceCase3.searchResTwoWeightTfidf_WFO1,
        con.divorceCase3.searchResTwoWeightTfidf_WLLR1,
    ]
    to_col = [
        con.divorceCase3.searchResWeightTfidf,
        con.divorceCase3.searchResTwoWeightTfidf_IG,
        con.divorceCase3.searchResTwoWeightTfidf_WFO,
        con.divorceCase3.searchResTwoWeightTfidf_WLLR,
    ]

    for fcol, tcol in zip(from_col, to_col):
        cur = fcol.find({}, no_cursor_timeout=True)
        for item in cur:
            refList = []
            for case in item['res']:
                refList.extend(case['ref'])
            topk = genSortStatutes(refList)
            item['topkStatute'] = topk

            tcol.insert(item)
        cur.close()