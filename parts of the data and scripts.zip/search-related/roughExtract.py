# 第一次：粗提取。
# 获取输入，进行分词，从索引表中提取出存在分词的案件的id
# 输入：从前端获取的字符串
# 输出：按tfidf值排序的id列表

import jieba

class roughExtract:
    def __init__(self, input):
        self.seg = list(jieba.cut_for_search(input))

    def getIndexList(self, searchId, disputeWordWeight, keyWordWeight, indextb):#通过加权tfidf获取查询结果

        midResult = dict()

        #所有包含关键字的案件的tfidf求和值
        for s in self.seg:
            for caseid,tfidf in indextb.getCaselistByKeyfortfidf(s).items():
                weight = 1
                if s in disputeWordWeight:
                    weight = disputeWordWeight[s]
                if s in keyWordWeight:
                    weight = weight * keyWordWeight[s]
                if caseid not in midResult:
                    midResult[caseid] = tfidf * weight
                else:
                    midResult[caseid] += tfidf * weight
        if searchId in midResult:
            midResult.pop(searchId)

        #对tfidf和排序
        sortRes = sorted(midResult.items(), key=lambda item: item[1],  reverse=True)
        res = dict()
        for item in sortRes:
            res[item[0]] = item[1]
            if len(res)>49:
                break

        return res