import pymongo, logging
import time
import pickle
import Case.searchRes.roughExtract as rx
import Case.searchRes.collection as sc

import logging

logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                datefmt='%a, %d %b %Y %H:%M:%S',
                filename='searchRes.log',
                filemode='w')

f = open("key-to-content", "rb")
d = pickle.load(f)
f.close()
d1 = dict()
for item in d.items():
    d1[item[0]] = item[1]['fomalname']+item[1]['num']

CON = pymongo.MongoClient('192.168.68.11', 20000)

#索引表
indextb = sc.indexTable()

import pickle

f1 = open("weightDict/disputeWordsWeight.pkl", "rb")
disputeWordWeight = pickle.load(f1)
f1.close()

f2 = open("weightDict/keyWordWeights_IG.pkl", "rb")
keyWordWeight_ig = pickle.load(f2)
f2.close()

f3 = open("weightDict/keyWordWeights_WFO.pkl", "rb")
keyWordWeight_wfo = pickle.load(f3)
f3.close()

f4 = open("weightDict/keyWordWeights_WLLR.pkl", "rb")
keyWordWeight_wllr = pickle.load(f4)
f4.close()


def standDispute(dispute):
    if dispute in d1:
        return d1[dispute]
    else:
        return dispute

def getcoverCount(standardList, testList):
    count = len(standardList & testList)
    return count

def gettestresult(idlist, col, referenceStandard):

    result = []
    for id in idlist:
        case = dict()
        case['id'] = id
        reference = set([standDispute(ref['name'].strip() + ref['levelone'].strip()) \
                     for ref in col.find_one({"fullTextId": id})['references']])
        case['ref'] = list(reference)
        case['covercount'] = getcoverCount(referenceStandard, reference)
        case['sim1'] = round(case['covercount']/(len(referenceStandard)+len(case['ref'])-case['covercount']), 4)
        P = case['covercount']/len(case['ref'])
        R = case['covercount']/len(referenceStandard)
        case['sim2'] = round(2 * P * R / (P + R), 4) if (P+R) != 0 else 0
        result.append(case)
    return result


def getStatuteList(serachRes):
    refList = []
    for case in item['res']:
        refList.extend(case['ref'])
    return refList


def genSortStatutes(refList):
    refDic = {}

    for ref in refList:
        if ref in refDic:
            refDic[ref] += 1
        else:
            refDic[ref] = 1

    refList = [(k, v) for k, v in refDic.items()]

    res = sorted(refList, key=lambda x: x[1], reverse=True)
    res = [{'statute': x[0], 'count':x[1]} for x in res]

    return res


def test(tag):
    #tag: 2:验证集，3测试集
    if tag not in ['2', '3', '4']:
        raise("tag error!")

    col1 = CON.divorceCase3.alldata
    col2 = CON.divorceCase3.lawreference
    col3 = CON.divorceCase3.searchResTwoWeightTfidf_IG
    col4 = CON.divorceCase3.searchResTwoWeightTfidf_WFO
    col5 = CON.divorceCase3.searchResTwoWeightTfidf_WLLR


    cur = col1.find({"tag": tag}, no_cursor_timeout=True)
    for caseids in cur:
        searchId = caseids['fullTextId']
        print(tag, ' ' , searchId)
        if col3.find_one({"searchId": searchId}) is not None:
            continue
        case = col1.find_one({"fullTextId": searchId})
        referenceStandard = set([standDispute(ref['name'].strip() + ref['levelone'].strip()) \
                             for ref in col2.find_one({"fullTextId": case['fullTextId']})['references']])

        res = dict()
        res['searchId'] = case['fullTextId']
        res['ref'] = list(referenceStandard)
        res['tag'] = case['tag']

        query = case['plaintiffAlleges']['text'] \
                + case['defendantArgued']['text'] \
                + case['factFound']['text']

        rough = rx.roughExtract(query)

        roughRes_ig = rough.getIndexList(disputeWordWeight, keyWordWeight_ig, indextb)
        res['res_ig'] = gettestresult(roughRes_ig, col2, referenceStandard)
        refList = getStatuteList(res['res_ig'])
        res['topkStatute_ig'] = genSortStatutes(refList)

        roughRes_wfo = rough.getIndexList(disputeWordWeight, keyWordWeight_wfo, indextb)
        res['res_wfo'] = gettestresult(roughRes_wfo, col2, referenceStandard)
        refList = getStatuteList(res['res_wfo'])
        res['topkStatute_wfo'] = genSortStatutes(refList)

        roughRes_wllr = rough.getIndexList(disputeWordWeight, keyWordWeight_wllr, indextb)
        res['res_wllr'] = gettestresult(roughRes_wllr, col2, referenceStandard)
        refList = getStatuteList(res['res_wllr'])
        res['topkStatute_wllr'] = genSortStatutes(refList)

        col3.insert({
            'searchId': res['searchId'],
            'ref': res['ref'],
            'tag': res['tag'],
            'res': res['res_ig'],
            'topkStatute': res['topkStatute_ig'],
        })
        col4.insert({
            'searchId': res['searchId'],
            'ref': res['ref'],
            'tag': res['tag'],
            'res': res['res_wfo'],
            'topkStatute': res['topkStatute_wfo'],
        })
        col5.insert({
            'searchId': res['searchId'],
            'ref': res['ref'],
            'tag': res['tag'],
            'res': res['res_wllr'],
            'topkStatute': res['topkStatute_wllr'],
        })
    cur.close()

if __name__ == '__main__':
    # tag = input("tag: 2:验证集，3测试集, 4..")
    logging.info('enter')
    s1 = time.time()
    test('2')
    test('3')
    test('4')
    s2 = time.time()
    logging.info("finish, cost: %g" % (s2 - s1))