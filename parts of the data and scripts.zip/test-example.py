import linecache
import pickle

import math


def take_last(elem):
    return elem[-1]


def prediction2result(prediction, test_data_file):
    result = {}

    qid = 0
    query_items = []
    for i in range(0, len(prediction)):
        # print('line:' + str(i))
        line = linecache.getline(test_data_file, i+1)
        space_index = line.find(' ')
        label = int(line[:space_index])

        sharp_index = line.find('#')
        searchId_lawname = line[sharp_index+1:]
        space_index = searchId_lawname.find(' ')
        searchId = searchId_lawname[:space_index]
        lawname = searchId_lawname[space_index+1:]
        lawname = lawname.strip()

        qid_index = line.find('qid:')
        line = line[qid_index + 4:]
        space_index = line.find(' ')
        line = line[:space_index]
        id = int(line)

        p = float(prediction[i])
        # p = float(prediction[i].split('\t')[2])
        if id == qid:
            query_items.append([searchId, lawname, label, p])
        else:
            if len(query_items) != 0:
                query_items.sort(key=take_last, reverse=True)
                case = {}
                for i in range(0, len(query_items)):
                    item = query_items[i]
                    case[item[1]] = {'rank': i+1, 'prediction': item[3]}
                    if item[2] == 5:
                        case[item[1]]['refed'] = 1
                    else:
                        case[item[1]]['refed'] = 0
                result[query_items[0][0]] = case
            qid = id
            query_items = [[searchId, lawname, label, p]]
    query_items.sort(key=take_last, reverse=True)
    case = {}
    rank = 1
    for item in query_items:
        case[item[1]] = {'rank': rank}
        rank += 1
        if item[2] == 5:
            case[item[1]]['refed'] = 1
        else:
            case[item[1]]['refed'] = 0
    result[query_items[0][0]] = case
    return result


case_law_dic_parts = []
for i in range(0, 5):
    file = open('UP/result-ref-part' + str(i), 'rb')
    dic_part = pickle.load(file)
    file.close()
    case_law_dic_parts.append(dic_part)


ref_fre = {}
for dic_part in case_law_dic_parts:
    for key in dic_part:
        for law in dic_part[key]:
            if dic_part[key][law]['refed'] == 'yes':
                ref_fre[law] = ref_fre.get(law, 0) + 1
#print(ref_fre)
#print(len(ref_fre))
i = 4
file = open('novel/prediction-' + str(i), 'r')
prediction = file.readlines()
file.close()
test_path = 'novel/test-' + str(i) + '.dat'
result = prediction2result(prediction, test_path)

ref_avg = [0] * 50
count = [0] * 50
for key in result:
    sortedRef = sorted(result[key].items(), key=lambda x: x[1]['rank'], reverse=False)
    num = 50 if len(sortedRef) > 50 else len(sortedRef)
    for i in range(0, num):
        ref_avg[i] += ref_fre.get(sortedRef[i][0], 0)
        count[i] += 1
for i in range(0, 50):
    ref_avg[i] /= count[i]

ref_avg2 = [0] * 50
law_set = []
for i in range(0, 50):
    law_set.append(set())
for key in result:
    sortedRef = sorted(result[key].items(), key=lambda x: x[1]['rank'], reverse=False)
    num = 50 if len(sortedRef) > 50 else len(sortedRef)
    for i in range(0, num):
        law_set[i].add(sortedRef[i][0])
for i in range(0, 50):
    for law in law_set[i]:
        ref_avg2[i] += ref_fre.get(law, 0)
    ref_avg2[i] /= len(law_set[i])

ref_avg3 = [0] * 50
count = [0] * 50
for key in result:
    sortedRef = sorted(result[key].items(), key=lambda x: x[1]['rank'], reverse=False)
    num = 50 if len(sortedRef) > 50 else len(sortedRef)
    for i in range(0, num):
        if result[key][sortedRef[i][0]]['refed'] == 1:
            ref_avg3[i] += ref_fre.get(sortedRef[i][0], 0)
            count[i] += 1
for i in range(0, 50):
    if count[i] > 0:
        ref_avg3[i] /= count[i]

ref_avg4 = [0] * 50
law_set = []
for i in range(0, 50):
    law_set.append(set())
for key in result:
    sortedRef = sorted(result[key].items(), key=lambda x: x[1]['rank'], reverse=False)
    num = 50 if len(sortedRef) > 50 else len(sortedRef)
    for i in range(0, num):
        if result[key][sortedRef[i][0]]['refed'] == 1:
            law_set[i].add(sortedRef[i][0])
for i in range(0, 50):
    if count[i] > 0:
        for law in law_set[i]:
            ref_avg4[i] += ref_fre.get(law, 0)
        ref_avg4[i] /= len(law_set[i])

print(ref_avg)
print(ref_avg2)
print(ref_avg3)
print(ref_avg4)
