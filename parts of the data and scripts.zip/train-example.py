
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"></ul></div>

# In[15]:


from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.preprocessing import LabelBinarizer
from sklearn.svm import SVC
from sklearn.multiclass import OneVsRestClassifier
from sklearn.externals import joblib
import numpy as np
import pickle


file = open('case-seg-dic-new', 'rb')
case_seg_dic_new = pickle.load(file)
file.close()
print(len(case_seg_dic_new))

file = open('law-seg-dic-new', 'rb')
law_seg_dic_new = pickle.load(file)
file.close()
print(len(law_seg_dic_new))

file = open('result-ref-0', 'rb')
result_ref_0 = pickle.load(file)
file.close()
print(len(result_ref_0))

file = open('result-ref-1', 'rb')
result_ref_1 = pickle.load(file)
file.close()
print(len(result_ref_1))

file = open('result-ref-2', 'rb')
result_ref_2 = pickle.load(file)
file.close()
print(len(result_ref_2))

file = open('result-ref-3', 'rb')
result_ref_3 = pickle.load(file)
file.close()
print(len(result_ref_3))

file = open('result-ref-4', 'rb')
result_ref_4 = pickle.load(file)
file.close()
print(len(result_ref_4))


# In[7]:


result_ref = [result_ref_0,result_ref_1,result_ref_2,result_ref_3,result_ref_4]

k = 1   # 把result_ref_k当做测试集，其余的当做训练集
result_ref_k = result_ref.pop(k)

X = []
Y = []


# In[8]:


# 构造训练集
for result_ref_x in result_ref:
    for searchId in result_ref_x:
        x = []
        y = []

        tf_idf = case_seg_dic_new[searchId]['tf-idf']
        ref_dict = result_ref_x[searchId]

        for word in tf_idf:
            x.append(tf_idf[word])

        for statute in ref_dict:
            if ref_dict[statute]['refed'] == 'yes':
                y.append(law_seg_dic_new[statute]['number'])
                
        X.append(x)
        Y.append(y)     


# In[9]:


# 构造测试集
for searchId in result_ref_k:
    x = []
    y = []
    
    tf_idf = case_seg_dic_new[searchId]['tf-idf']
    ref_dict = result_ref_k[searchId]

    for word in tf_idf:
        x.append(tf_idf[word])

    for statute in ref_dict:
        if ref_dict[statute]['refed'] == 'yes':
            y.append(law_seg_dic_new[statute]['number'])

    X.append(x)
    Y.append(y)


# In[10]:


X_train = np.asarray(X[0:15840])
X_test = np.asarray(X[15840:])
print(X_train.shape)
print(X_test.shape)


# In[11]:


Y = MultiLabelBinarizer().fit_transform(Y)


# In[13]:


Y_train = Y[0:15840]
Y_test = Y[15840:]
print(Y_train.shape)
print(Y_test.shape)


# In[ ]:


classif = OneVsRestClassifier(estimator=SVC(gamma='auto',random_state=0))
classif.fit(X_train, Y_train)


# In[ ]:


joblib.dump(classif, "model_1.joblib")

